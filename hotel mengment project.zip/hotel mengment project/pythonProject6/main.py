import sys
import os

# קביעת נתיב לפרויקט
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# ייבוא מנהלים
from managers.guest_manager import GuestManager
from managers.room_manager import RoomManager
from managers.booking_manager import BookingManager

# ייבוא התפריט הראשי
from interfaces.main_menu_cli import MainMenu  # <-- שינוי פה

def main():
    # טעינת אורחים, חדרים
    guest_manager = GuestManager()
    room_manager = RoomManager()

    # יצירת booking manager עם המנהלים
    booking_manager = BookingManager(guest_manager, room_manager)

    # יצירת תפריט ראשי
    menu = MainMenu(room_manager, guest_manager, booking_manager)  # <-- שינוי פה
    menu.run()

if __name__ == "__main__":
    main()

