# interfaces/room_cli.py

from datetime import datetime

class RoomCLI:
    MIN_PRICES = {
        "single": 250,
        "double": 400,
        "suite": 700,
        "deluxe": 1000
    }

    def __init__(self, room_manager, booking_manager=None):
        self.room_manager = room_manager
        self.booking_manager = booking_manager

    def show_menu(self):
        while True:
            print("\n--- Room Management Menu ---")
            print("1. Add Room")
            print("2. View Room")
            print("3. Update Room")
            print("4. Delete Room")
            print("5. Back to Main Menu")

            choice = input("Enter your choice (1-5): ").strip()

            if choice == "1":
                self.add_room()
            elif choice == "2":
                self.view_room()
            elif choice == "3":
                self.update_room()
            elif choice == "4":
                self.delete_room()
            elif choice == "5":
                break
            else:
                print("Invalid choice.")

    def add_room(self):
        room_number = input("Enter room number: ").strip()
        print("Choose room type:")
        print("1. single\n2. double\n3. suite\n4. deluxe")
        type_choice = input("Enter choice (1-4): ").strip()

        room_types = ["single", "double", "suite", "deluxe"]
        if type_choice in ["1", "2", "3", "4"]:
            room_type = room_types[int(type_choice) - 1]
        else:
            print("Invalid room type.")
            return

        try:
            price = float(input(f"Enter price for {room_type} room (minimum {self.MIN_PRICES[room_type]}): "))
            if price < self.MIN_PRICES[room_type]:
                print(f"Price too low. Must be at least {self.MIN_PRICES[room_type]}.")
                return
        except ValueError:
            print("Invalid price format.")
            return

        self.room_manager.create_room(room_number, room_type, price)

    def view_room(self):
        room_number = input("Enter room number to view: ").strip()
        room = self.room_manager.get_room(room_number)
        if room:
            print(f"Room {room.room_number}: {room.get_type()}, ${room.price}")
        else:
            print("Room not found.")

    def update_room(self):
        room_number = input("Enter room number to update: ").strip()
        room = self.room_manager.get_room(room_number)
        if not room:
            print("Room not found.")
            return

        room_type = room.get_type().lower().replace(" room", "")
        print(f"Current room type: {room.get_type()}, price: {room.price}")
        price_input = input(f"Enter new price (minimum {self.MIN_PRICES[room_type]}) or press Enter to skip: ").strip()

        if price_input:
            try:
                price = float(price_input)
                if price < self.MIN_PRICES[room_type]:
                    print(f"Price too low. Minimum for {room_type} is {self.MIN_PRICES[room_type]}.")
                    return
            except ValueError:
                print("Invalid price format.")
                return
        else:
            price = None

        self.room_manager.update_room(room_number, price=price)

    def delete_room(self):
        room_number = input("Enter room number to delete: ").strip()
        self.room_manager.delete_room(room_number)