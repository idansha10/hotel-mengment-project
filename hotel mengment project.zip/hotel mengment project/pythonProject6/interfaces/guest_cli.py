class GuestCLI:
    def __init__(self, guest_manager):
        self.guest_manager = guest_manager

    def show_menu(self):
        while True:
            print("\nGuest Menu:")
            print("1. Register guest")
            print("2. Update guest")
            print("3. List all guests")
            print("4. Delete guest")
            print("5. Back to main menu")

            choice = input("Enter choice (1-5): ")

            if choice == "1":
                self.register_guest()
            elif choice == "2":
                self.update_guest()
            elif choice == "3":
                self.list_all_guests()
            elif choice == "4":
                self.delete_guest()
            elif choice == "5":
                break
            else:
                print("Invalid choice. Try again.")

    def register_guest(self):
        guest_id = input("Enter guest ID (9 digits): ")
        name = input("Enter guest name: ")
        phone = input("Enter guest phone (10 digits): ")

        print("Select guest type:")
        print("1. Regular")
        print("2. Member")
        print("3. VIP")

        guest_type_choice = input("Enter choice (1-3): ")
        guest_type = None
        if guest_type_choice == "1":
            guest_type = "regular"
        elif guest_type_choice == "2":
            guest_type = "member"
        elif guest_type_choice == "3":
            guest_type = "vip"
        else:
            print("Invalid guest type choice.")
            return

        from models.guest import Guest  # Import כאן כדי להימנע מלולאה
        guest = Guest(guest_id, name, phone, guest_type)

        self.guest_manager.add_guest(guest)

    def update_guest(self):
        guest_id = input("Enter guest ID to update: ")
        name = input("Enter new name (leave empty to keep current): ")
        phone = input("Enter new phone (leave empty to keep current): ")

        print("Select new guest type:")
        print("1. Regular")
        print("2. Member")
        print("3. VIP")
        guest_type_choice = input("Enter choice (1-3), or leave empty to keep current: ")

        guest_type = None
        if guest_type_choice == "1":
            guest_type = "regular"
        elif guest_type_choice == "2":
            guest_type = "member"
        elif guest_type_choice == "3":
            guest_type = "vip"
        elif guest_type_choice.strip() == "":
            guest_type = None
        else:
            print("Invalid choice.")
            return

        self.guest_manager.update_guest(guest_id, name=name or None, phone=phone or None, guest_type=guest_type)

    def list_all_guests(self):
        self.guest_manager.list_all_guests()

    def delete_guest(self):
        guest_id = input("Enter guest ID to delete: ")
        self.guest_manager.delete_guest(guest_id)