from datetime import datetime

class BookingCLI:
    def __init__(self, booking_manager):
        self.booking_manager = booking_manager

    def show_menu(self):
        while True:
            print("\n--- Booking Management Menu ---")
            print("1. Create Booking")
            print("2. Update Booking Dates")
            print("3. Update Booking Status")
            print("4. Mark Booking as Paid")
            print("5. Cancel Booking")
            print("6. View All Bookings")
            print("7. Generate Invoice")  # <-- חדש
            print("8. Back to Main Menu")

            choice = input("Enter your choice (1-8): ").strip()

            if choice == "1":
                self.create_booking()
            elif choice == "2":
                self.update_booking_dates()
            elif choice == "3":
                self.update_booking_status()
            elif choice == "4":
                self.mark_booking_as_paid()
            elif choice == "5":
                self.cancel_booking()
            elif choice == "6":
                self.view_all_bookings()
            elif choice == "7":
                self.generate_invoice()  # <-- חדש
            elif choice == "8":
                print("Returning to Main Menu...")
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 8.")

    def create_booking(self):
        booking_id = input("Enter booking ID: ").strip()
        guest_id = input("Enter guest ID: ").strip()
        guest = self.booking_manager.guest_manager.get_guest(guest_id)
        if not guest:
            print(f"Guest with ID {guest_id} not found.")
            return

        room_number = input("Enter room number: ").strip()
        room = self.booking_manager.room_manager.get_room(room_number)
        if not room:
            print(f"Room {room_number} not found.")
            return

        try:
            check_in_str = input("Enter check-in date (dd-mm-yyyy): ").strip()
            check_out_str = input("Enter check-out date (dd-mm-yyyy): ").strip()
            check_in_date = datetime.strptime(check_in_str + " 11:00", "%d-%m-%Y %H:%M")
            check_out_date = datetime.strptime(check_out_str + " 10:00", "%d-%m-%Y %H:%M")

            if check_in_date >= check_out_date:
                print("Check-out must be after check-in.")
                return
            if check_in_date.date() < datetime.now().date():
                print("Check-in date cannot be in the past.")
                return

            use_points = False
            if guest.guest_type == "member" and guest.points > 0:
                print(f"Guest is a Member with {guest.points} points.")
                print("Do you want to use points for this booking?")
                print("1. Yes")
                print("2. No")
                use_points_choice = input("Enter your choice (1-2): ").strip()
                use_points = use_points_choice == "1"

            # קורא ל-BookingManager
            self.booking_manager.create_booking(
                booking_id, guest_id, room_number, check_in_date, check_out_date, use_points
            )

        except ValueError:
            print("Invalid date format. Please use dd-mm-yyyy.")

    def update_booking_dates(self):
        booking_id = input("Enter booking ID to update dates: ").strip()
        try:
            check_in_str = input("Enter new check-in date (dd-mm-yyyy) or leave blank to keep: ").strip()
            check_out_str = input("Enter new check-out date (dd-mm-yyyy) or leave blank to keep: ").strip()

            check_in_date = datetime.strptime(check_in_str + " 11:00", "%d-%m-%Y %H:%M") if check_in_str else None
            check_out_date = datetime.strptime(check_out_str + " 10:00", "%d-%m-%Y %H:%M") if check_out_str else None

            self.booking_manager.update_booking(booking_id, check_in_date, check_out_date)
        except ValueError:
            print("Invalid date format. Please use dd-mm-yyyy.")

    def update_booking_status(self):
        booking_id = input("Enter booking ID to update status: ").strip()
        status_options = ["confirmed", "checked-in", "checked-out", "cancelled"]
        print("Select new status:")
        for idx, status in enumerate(status_options, 1):
            print(f"{idx}. {status}")
        status_choice = input("Enter choice (1-4): ").strip()
        if status_choice in ["1", "2", "3", "4"]:
            new_status = status_options[int(status_choice) - 1]
            self.booking_manager.update_booking_status(booking_id, new_status)
        else:
            print("Invalid choice.")

    def mark_booking_as_paid(self):
        booking_id = input("Enter booking ID to mark as paid: ").strip()
        self.booking_manager.mark_booking_as_paid(booking_id)

    def cancel_booking(self):
        booking_id = input("Enter booking ID to cancel: ").strip()
        self.booking_manager.cancel_booking(booking_id)

    def view_all_bookings(self):
        self.booking_manager.list_bookings()

    def generate_invoice(self):  # <-- פונקציה חדשה
        booking_id = input("Enter booking ID for invoice: ").strip()
        self.booking_manager.generate_invoice(booking_id)