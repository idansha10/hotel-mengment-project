from interfaces.room_cli import RoomCLI
from interfaces.guest_cli import GuestCLI
from interfaces.booking_cli import BookingCLI
from interfaces.managerial_cli import ManagerialCLI
from interfaces.reporting_cli import ReportingCLI


class MainMenu:
    def __init__(self, room_manager, guest_manager, booking_manager):
        self.room_cli = RoomCLI(room_manager, booking_manager)
        self.guest_cli = GuestCLI(guest_manager)
        self.booking_cli = BookingCLI(booking_manager)
        self.managerial_cli = ManagerialCLI(room_manager, guest_manager, booking_manager)
        self.reporting_cli = ReportingCLI(room_manager, booking_manager, guest_manager)

    def run(self):
        while True:
            print("\n--- Hotel Management System ---")
            print("1. Room Management")
            print("2. Guest Management")
            print("3. Booking Management")
            print("4. Reporting Menu")
            print("5. Managerial Menu")
            print("6. Exit")

            choice = input("Enter your choice (1-6): ").strip()

            if choice == "1":
                self.room_cli.show_menu()

            elif choice == "2":
                self.guest_cli.show_menu()

            elif choice == "3":
                self.booking_cli.show_menu()

            elif choice == "4":
                self.reporting_cli.show_menu()

            elif choice == "5":
                self.managerial_cli.show_menu()

            elif choice == "6":
                print("Exiting... Goodbye!")
                break

            else:
                print("Invalid choice. Please select between 1 and 6.")

