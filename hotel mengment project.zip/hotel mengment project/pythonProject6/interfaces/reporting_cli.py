from datetime import datetime

class ReportingCLI:
    def __init__(self, room_manager, booking_manager, guest_manager):
        self.room_manager = room_manager
        self.booking_manager = booking_manager
        self.guest_manager = guest_manager

    def show_menu(self):
        while True:
            print("\n--- Reports Menu ---")
            print("1. Occupancy Rate Summary (Today)")
            print("2. Booking Summary")
            print("3. Search Bookings by Date")
            print("4. Search Bookings by Guest Name")
            print("5. List All Guests")
            print("6. Back to Main Menu")

            choice = input("Enter your choice (1-6): ").strip()

            if choice == "1":
                self.occupancy_rate_summary()
            elif choice == "2":
                self.booking_summary()
            elif choice == "3":
                self.search_bookings_by_date()
            elif choice == "4":
                self.search_bookings_by_guest_name()
            elif choice == "5":
                self.list_all_guests()
            elif choice == "6":
                print("Returning to Main Menu...")
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 6.")

    def occupancy_rate_summary(self):
        today = datetime.now().date()
        total_rooms = len(self.room_manager.rooms)
        occupied = 0
        for booking in self.booking_manager.bookings.values():
            if booking.check_in_date.date() <= today <= booking.check_out_date.date():
                occupied += 1
        if total_rooms == 0:
            print("No rooms in the system.")
        else:
            occupancy_rate = (occupied / total_rooms) * 100
            print(f"Occupied Rooms Today: {occupied} / {total_rooms} ({occupancy_rate:.2f}%)")

    def booking_summary(self):
        print("\n--- Booking Summary ---")
        total_bookings = len(self.booking_manager.bookings)
        print(f"Total Bookings: {total_bookings}")
        if total_bookings > 0:
            check_in_dates = [b.check_in_date for b in self.booking_manager.bookings.values()]
            first_booking = min(check_in_dates).strftime('%d-%m-%Y')
            latest_booking = max(check_in_dates).strftime('%d-%m-%Y')
            print(f"First Booking Date : {first_booking}")
            print(f"Latest Booking Date: {latest_booking}")
        else:
            print("No bookings found.")

    def search_bookings_by_date(self):
        date_str = input("Enter date to search (dd-mm-yyyy): ").strip()
        try:
            target_date = datetime.strptime(date_str, "%d-%m-%Y")
            self.booking_manager.search_bookings_by_date(target_date)
        except ValueError:
            print("Invalid date format. Please use dd-mm-yyyy.")

    def search_bookings_by_guest_name(self):
        guest_name = input("Enter guest name to search: ").strip()
        self.booking_manager.search_bookings_by_guest_name(guest_name)

    def list_all_guests(self):
        self.guest_manager.list_all_guests()