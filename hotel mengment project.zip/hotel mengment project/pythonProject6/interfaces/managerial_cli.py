class ManagerialCLI:
    def __init__(self, room_manager, guest_manager, booking_manager):
        self.room_manager = room_manager
        self.guest_manager = guest_manager
        self.booking_manager = booking_manager

    def show_menu(self):
        while True:
            print("\n--- Managerial Menu ---")
            print("1. Adjust Room Price")
            print("2. View All Rooms")
            print("3. View All Guests")
            print("4. View All Bookings")
            print("5. View Room Availability Report")
            print("6. Back to Main Menu")

            choice = input("Enter your choice (1-6): ").strip()

            if choice == "1":
                self.adjust_room_price()

            elif choice == "2":
                self.view_all_rooms()

            elif choice == "3":
                self.view_all_guests()

            elif choice == "4":
                self.view_all_bookings()

            elif choice == "5":
                self.view_room_availability_report()

            elif choice == "6":
                print("Returning to Main Menu...")
                break

            else:
                print("Invalid choice. Please try again.")

    def adjust_room_price(self):
        room_number = input("Enter room number to update price: ").strip()
        try:
            new_price = float(input("Enter new price: ").strip())
            self.room_manager.update_room_price(room_number, new_price)
        except ValueError:
            print("Invalid price input.")

    def view_all_rooms(self):
        self.room_manager.show_all_rooms_with_status(self.booking_manager)

    def view_all_guests(self):
        if not self.guest_manager.guests:
            print("No guests found.")
        else:
            for guest in self.guest_manager.guests.values():
                print(f"Guest {guest.guest_id}: {guest.name}, Phone: {guest.phone}")

    def view_all_bookings(self):
        self.booking_manager.list_bookings()

    def view_room_availability_report(self):
        self.room_manager.show_room_availability_report(self.booking_manager)
