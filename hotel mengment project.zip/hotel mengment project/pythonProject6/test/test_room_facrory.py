import unittest
from models.room_factory import RoomFactory
from models.room import SingleRoom, DoubleRoom, SuiteRoom, DeluxeRoom

class TestRoomFactory(unittest.TestCase):
    def test_create_single_room(self):
        room = RoomFactory.create_room("single", "201", 300)
        self.assertIsInstance(room, SingleRoom)

    def test_create_invalid_room(self):
        with self.assertRaises(ValueError):
            RoomFactory.create_room("penthouse", "301", 2000)

if __name__ == "__main__":
    unittest.main()