import unittest
import json
import os
from managers.guest_manager import GuestManager
from models.guest import Guest

class TestGuestManager(unittest.TestCase):
    def setUp(self):
        os.makedirs("test_data", exist_ok=True)
        self.guest_file = "test_data/guests_test.json"
        with open(self.guest_file, "w") as f:
            json.dump({}, f)

        self.guest_manager = GuestManager(filename=self.guest_file)

    def tearDown(self):
        if os.path.exists(self.guest_file):
            os.remove(self.guest_file)

    def test_add_guest(self):
        guest = Guest("G001", "Alice", "050-1111111", guest_type="regular")
        self.guest_manager.add_guest(guest)
        self.assertIn("G001", self.guest_manager.guests)

    def test_get_guest(self):
        guest = Guest("G001", "Alice", "050-1111111", guest_type="vip")
        self.guest_manager.add_guest(guest)
        retrieved_guest = self.guest_manager.get_guest("G001")
        self.assertEqual(retrieved_guest.name, "Alice")

    def test_delete_guest(self):
        guest = Guest("G001", "Alice", "050-1111111", guest_type="member")
        self.guest_manager.add_guest(guest)
        self.guest_manager.delete_guest("G001")
        self.assertNotIn("G001", self.guest_manager.guests)

if __name__ == "__main__":
    unittest.main()