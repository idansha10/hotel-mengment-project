import unittest
import json
import os
from datetime import datetime, timedelta
from managers.booking_manager import BookingManager
from managers.guest_manager import GuestManager
from managers.room_manager import RoomManager
from managers.waitlist_manager import WaitlistManager
from models.guest import Guest
from models.room import SingleRoom

class TestBookingManager(unittest.TestCase):
    def setUp(self):
        os.makedirs("test_data", exist_ok=True)

        self.guest_file = "test_data/guests_test.json"
        self.room_file = "test_data/rooms_test.json"
        self.booking_file = "test_data/bookings_test.json"
        self.waitlist_file = "test_data/waitlist_test.json"

        for file in [self.guest_file, self.room_file, self.booking_file, self.waitlist_file]:
            with open(file, "w") as f:
                json.dump({}, f)

        self.guest_manager = GuestManager(filename=self.guest_file)
        self.room_manager = RoomManager(filename=self.room_file)
        self.booking_manager = BookingManager(self.guest_manager, self.room_manager, filename=self.booking_file)
        self.waitlist_manager = WaitlistManager(filename=self.waitlist_file)
        self.booking_manager.set_waitlist_manager(self.waitlist_manager)

        self.guest = Guest("G001", "Alice", "050-1111111", guest_type="regular")
        self.room = SingleRoom("101", 300)

        self.guest_manager.guests[self.guest.guest_id] = self.guest
        self.room_manager.rooms[self.room.room_number] = self.room

        self.check_in = datetime.now() + timedelta(days=5)
        self.check_out = self.check_in + timedelta(days=2)

    def tearDown(self):
        for file in [self.guest_file, self.room_file, self.booking_file, self.waitlist_file]:
            if os.path.exists(file):
                os.remove(file)

    def test_create_booking_success(self):
        self.booking_manager.create_booking(
            "B001", self.guest.guest_id, self.room.room_number, self.check_in, self.check_out
        )
        self.assertIn("B001", self.booking_manager.bookings)

    def test_booking_waitlist_when_room_taken(self):
        self.booking_manager.create_booking(
            "B001", self.guest.guest_id, self.room.room_number, self.check_in, self.check_out
        )
        guest2 = Guest("G002", "Bob", "050-2222222", guest_type="regular")
        self.guest_manager.guests[guest2.guest_id] = guest2

        self.booking_manager.create_booking(
            "B002", guest2.guest_id, self.room.room_number, self.check_in, self.check_out
        )
        waitlist = self.waitlist_manager.waitlist.get(self.room.room_number, [])
        guest_ids = [g["guest_id"] for g in waitlist]
        self.assertIn(guest2.guest_id, guest_ids)

    def test_mark_booking_as_paid(self):
        self.booking_manager.create_booking(
            "B003", self.guest.guest_id, self.room.room_number, self.check_in, self.check_out
        )
        self.booking_manager.mark_booking_as_paid("B003")
        self.assertTrue(self.booking_manager.bookings["B003"].is_paid)

    def test_cancel_booking(self):
        self.booking_manager.create_booking(
            "B004", self.guest.guest_id, self.room.room_number, datetime.now() + timedelta(hours=30), datetime.now() + timedelta(hours=54)
        )
        self.booking_manager.cancel_booking("B004")
        self.assertNotIn("B004", self.booking_manager.bookings)

    def test_calculate_total_price(self):
        self.booking_manager.create_booking(
            "B005", self.guest.guest_id, self.room.room_number, self.check_in, self.check_out
        )
        price = self.booking_manager.calculate_total_price("B005")
        self.assertEqual(price, 2 * self.room.price)

if __name__ == "__main__":
    unittest.main()