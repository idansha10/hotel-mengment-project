import unittest
from datetime import datetime, timedelta
from models.guest import Guest
from models.room import SingleRoom
from models.booking import Booking
from models.cancellation_strategies import (
    RegularCancellationStrategy,
    MemberCancellationStrategy,
    VIPCancellationStrategy
)

class TestCancellationStrategies(unittest.TestCase):
    def setUp(self):
        self.guest_regular = Guest("G001", "Alice", "050-1111111", guest_type="regular")
        self.guest_member = Guest("G002", "Bob", "050-2222222", guest_type="member")
        self.guest_vip = Guest("G003", "Charlie", "050-3333333", guest_type="vip")

        self.room = SingleRoom("101", 300)
        self.check_in = datetime.now() + timedelta(days=1)
        self.check_out = self.check_in + timedelta(days=3)

        self.booking = Booking("B001", self.guest_regular.guest_id, self.room.room_number, self.check_in, self.check_out)

    def test_regular_cancellation_fee(self):
        strategy = RegularCancellationStrategy()
        fee = strategy.calculate_fee(self.booking, self.guest_regular, self.room)
        self.assertEqual(fee, 0.3 * (3 * 300))

    def test_member_cancellation_fee(self):
        strategy = MemberCancellationStrategy()
        fee = strategy.calculate_fee(self.booking, self.guest_member, self.room)
        self.assertEqual(fee, 0.2 * (3 * 300))

    def test_vip_cancellation_fee(self):
        strategy = VIPCancellationStrategy()
        fee = strategy.calculate_fee(self.booking, self.guest_vip, self.room)
        self.assertEqual(fee, 0.1 * (3 * 300))

if __name__ == "__main__":
    unittest.main()