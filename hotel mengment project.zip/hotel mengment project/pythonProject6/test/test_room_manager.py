import unittest
import json
import os
from managers.room_manager import RoomManager

class TestRoomManager(unittest.TestCase):
    def setUp(self):
        os.makedirs("test_data", exist_ok=True)
        self.room_file = "test_data/rooms_test.json"
        with open(self.room_file, "w") as f:
            json.dump({}, f)

        self.room_manager = RoomManager(filename=self.room_file)

    def tearDown(self):
        if os.path.exists(self.room_file):
            os.remove(self.room_file)

    def test_create_room(self):
        self.room_manager.create_room("101", "single", 300)
        self.assertIn("101", self.room_manager.rooms)

    def test_update_room_price(self):
        self.room_manager.create_room("102", "double", 500)
        self.room_manager.update_room_price("102", 600)
        self.assertEqual(self.room_manager.rooms["102"].price, 600)

    def test_delete_room(self):
        self.room_manager.create_room("103", "suite", 800)
        self.room_manager.delete_room("103")
        self.assertNotIn("103", self.room_manager.rooms)

if __name__ == "__main__":
    unittest.main()