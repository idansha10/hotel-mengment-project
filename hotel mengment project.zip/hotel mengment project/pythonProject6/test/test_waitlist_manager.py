import unittest
import os
import json
from managers.waitlist_manager import WaitlistManager

class TestWaitlistManager(unittest.TestCase):
    def setUp(self):
        self.filename = "test_data/waitlist_test.json"
        os.makedirs("test_data", exist_ok=True)
        with open(self.filename, "w") as f:
            json.dump({}, f)
        self.waitlist_manager = WaitlistManager(filename=self.filename)

    def tearDown(self):
        if os.path.exists(self.filename):
            os.remove(self.filename)

    def test_add_to_waitlist(self):
        self.waitlist_manager.add_to_waitlist("101", "G001")
        self.assertIn("101", self.waitlist_manager.waitlist)
        self.assertEqual(self.waitlist_manager.waitlist["101"][0]["guest_id"], "G001")

    def test_get_next_guest(self):
        self.waitlist_manager.add_to_waitlist("101", "G001")
        self.waitlist_manager.add_to_waitlist("101", "G002")
        next_guest = self.waitlist_manager.get_next_guest("101")
        self.assertEqual(next_guest["guest_id"], "G001")

if __name__ == "__main__":
    unittest.main()