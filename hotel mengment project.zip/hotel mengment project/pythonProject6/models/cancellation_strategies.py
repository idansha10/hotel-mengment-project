# models/cancellation_strategies.py

class CancellationStrategy:
    """
    Interface עבור חישוב דמי ביטול.
    """
    def calculate_fee(self, booking, guest, room):
        raise NotImplementedError("Subclasses must implement this method.")

class RegularCancellationStrategy(CancellationStrategy):
    def calculate_fee(self, booking, guest, room):
        nights = (booking.check_out_date - booking.check_in_date).days
        total_price = nights * room.price
        return 0.30 * total_price  # 30% קנס ביטול

class MemberCancellationStrategy(CancellationStrategy):
    def calculate_fee(self, booking, guest, room):
        nights = (booking.check_out_date - booking.check_in_date).days
        total_price = nights * room.price
        return 0.20 * total_price  # 20% קנס ביטול

class VIPCancellationStrategy(CancellationStrategy):
    def calculate_fee(self, booking, guest, room):
        nights = (booking.check_out_date - booking.check_in_date).days
        total_price = nights * room.price
        return 0.10 * total_price  # 10% קנס ביטול