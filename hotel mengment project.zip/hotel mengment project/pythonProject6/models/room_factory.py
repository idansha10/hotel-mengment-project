# models/room_factory.py

from models.room import SingleRoom, DoubleRoom, DeluxeRoom, SuiteRoom

class RoomFactory:
    _room_types = {
        "single": SingleRoom,
        "double": DoubleRoom,
        "suite": SuiteRoom,
        "deluxe": DeluxeRoom
    }

    @classmethod
    def create_room(cls, room_type, room_number, price):
        """
        Creates a room object based on the room type.
        """
        room_class = cls._room_types.get(room_type.lower())
        if not room_class:
            raise ValueError(f"Invalid room type: {room_type}")
        return room_class(room_number, price)

    @classmethod
    def register_room_type(cls, type_name, room_class):
        """
        Register a new room type dynamically.
        """
        cls._room_types[type_name.lower()] = room_class