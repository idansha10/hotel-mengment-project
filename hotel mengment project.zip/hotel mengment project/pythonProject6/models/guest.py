class Guest:
    def __init__(self, guest_id, name, phone, guest_type="regular", points=0, is_paid=False):
        self.guest_id = guest_id
        self.name = name
        self.phone = phone
        self.guest_type = guest_type  # "regular", "member", "vip"
        self.points = points  # לצבירת נקודות של חבר מועדון
        self.is_paid = is_paid  # האם שילם על הצטרפות

    def to_dict(self):
        return {
            "guest_id": self.guest_id,
            "name": self.name,
            "phone": self.phone,
            "guest_type": self.guest_type,
            "points": self.points,
            "is_paid": self.is_paid
        }

    def __str__(self):
        return (f"Guest {self.guest_id}: {self.name}, Phone: {self.phone}, "
                f"Type: {self.guest_type}, Points: {self.points}, Paid: {'Yes' if self.is_paid else 'No'}")
