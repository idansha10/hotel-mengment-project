from datetime import datetime

class Booking:
    VALID_STATUSES = ["confirmed", "checked-in", "checked-out", "cancelled"]

    def __init__(self, booking_id, guest_id, room_number, check_in_date, check_out_date,
                 status="confirmed", is_paid=False, points_used=0, discount_from_points=0):
        self.booking_id = booking_id
        self.guest_id = guest_id
        self.room_number = room_number
        self.check_in_date = check_in_date  # datetime object
        self.check_out_date = check_out_date  # datetime object
        self.status = status
        self.is_paid = is_paid  # Boolean flag if paid
        self.points_used = points_used
        self.discount_from_points = discount_from_points

    def _str_(self):
        nights = self.nights_count()
        return (f"Booking {self.booking_id}: Guest {self.guest_id}, Room {self.room_number}, "
                f"From {self.check_in_date.strftime('%d-%m-%Y %H:%M')} to {self.check_out_date.strftime('%d-%m-%Y %H:%M')} "
                f"({nights} night(s)), Status: {self.status}, Paid: {'Yes' if self.is_paid else 'No'}, "
                f"Points Used: {self.points_used}")

    def nights_count(self):
        return (self.check_out_date - self.check_in_date).days

    def to_dict(self):
        return {
            "booking_id": self.booking_id,
            "guest_id": self.guest_id,
            "room_number": self.room_number,
            "check_in_date": self.check_in_date.strftime("%d-%m-%Y %H:%M"),
            "check_out_date": self.check_out_date.strftime("%d-%m-%Y %H:%M"),
            "status": self.status,
            "is_paid": self.is_paid,
            "points_used": self.points_used,
            "discount_from_points": self.discount_from_points
        }
