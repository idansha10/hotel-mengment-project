class Room:
    def __init__(self, room_number, price, is_available=True):
        self.room_number = room_number
        self.price = price
        self.is_available = is_available

    def get_type(self):
        return "Generic Room"

    def calculate_price(self):
        return self.price

    def __str__(self):
        return f"Room {self.room_number}: {self.get_type()}, ${self.calculate_price()}"


class SingleRoom(Room):
    def get_type(self):
        return "Single Room"


class DoubleRoom(Room):
    def get_type(self):
        return "Double Room"


class SuiteRoom(Room):
    def get_type(self):
        return "Suite Room"


class DeluxeRoom(Room):
    def get_type(self):
        return "Deluxe Room"

    def calculate_price(self):
        # מחיר מוגדל ב-20% לחדרי דלוקס
        return round(self.price * 1.2, 2)
