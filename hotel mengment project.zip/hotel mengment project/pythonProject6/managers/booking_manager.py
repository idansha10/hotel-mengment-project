import json
import os
from datetime import datetime
from models.booking import Booking
from models.cancellation_strategies import (
    RegularCancellationStrategy,
    MemberCancellationStrategy,
    VIPCancellationStrategy
)

class BookingManager:
    def __init__(self, guest_manager, room_manager, filename="data/bookings.json"):
        self.bookings = {}
        self.guest_manager = guest_manager
        self.room_manager = room_manager
        self.waitlist_manager = None
        self.filename = filename
        self.load_from_file()

    def set_waitlist_manager(self, waitlist_manager):
        self.waitlist_manager = waitlist_manager

    def create_booking(self, booking_id, guest_id, room_number, check_in_date, check_out_date, use_points=False,
                       points_to_use=0):
        if booking_id in self.bookings:
            print("Booking already exists.")
            return

        guest = self.guest_manager.get_guest(guest_id)
        if not guest:
            print(f"Guest with ID {guest_id} does not exist.")
            return

        room = self.room_manager.get_room(room_number)
        if not room:
            print(f"Room {room_number} does not exist.")
            return

        for existing_booking in self.bookings.values():
            if existing_booking.room_number == room_number:
                if not (
                        check_out_date <= existing_booking.check_in_date or check_in_date >= existing_booking.check_out_date):
                    print("Room is not available for the selected dates.")
                    if self.waitlist_manager:
                        self.waitlist_manager.add_to_waitlist(room_number, guest_id)
                        print(f"Guest {guest_id} added to waitlist for Room {room_number}.")
                    return

        booking = Booking(
            booking_id, guest_id, room_number, check_in_date, check_out_date, status="confirmed", is_paid=False
        )

        if guest.guest_type == "member" and use_points:
            if guest.points == 0:
                print(f"Guest {guest.name} has no points available to use.")
                print("Proceeding without points discount.")
                booking.points_used = 0
                booking.discount_from_points = 0
            else:
                room_type = room.get_type().lower()
                price_per_night = {
                    "single room": 10,
                    "double room": 15,
                    "deluxe room": 20,
                    "suite room": 25
                }.get(room_type, 0)

                if price_per_night > 0:
                    print(f"Guest is booking Room {room.room_number} ({room.get_type()}).")
                    print(f"You need {price_per_night} points for one free night in this room.")

                    # ✅ אם points_to_use הוא 0 — נשאל את המשתמש!
                    if points_to_use <= 0:
                        while True:
                            points_input = input(
                                "How many points would you like to use? (Press Enter for maximum points): ").strip()
                            if points_input == "":
                                # אוטומטית נחשב את המקסימום
                                free_nights_possible = guest.points // price_per_night
                                points_to_use = free_nights_possible * price_per_night
                                break
                            else:
                                if points_input.isdigit() and int(points_input) > 0:
                                    points_to_use = int(points_input)
                                    if points_to_use > guest.points:
                                        print(f"You only have {guest.points} points. Using maximum available.")
                                        points_to_use = guest.points
                                    break
                                else:
                                    print(
                                        "Invalid input. Please enter a positive number or press Enter for maximum points.")

                    if points_to_use > guest.points:
                        print(
                            f"Requested {points_to_use} points but only {guest.points} points are available. Using {guest.points} points instead.")
                        points_to_use = guest.points

                    free_nights = points_to_use // price_per_night
                    real_points_used = free_nights * price_per_night
                    discount_amount = free_nights * room.price

                    booking.points_used = real_points_used
                    booking.discount_from_points = discount_amount

                    guest.points -= real_points_used
                else:
                    booking.points_used = 0
                    booking.discount_from_points = 0
        else:
            booking.points_used = 0
            booking.discount_from_points = 0

        self.bookings[booking_id] = booking
        print(f"Booking {booking_id} created successfully.")

        self.save_to_file()
        self.guest_manager.save_guests()

        if guest.guest_type == "member":
            print(f"You now have {guest.points} points remaining.")

    def update_booking(self, booking_id, check_in_date=None, check_out_date=None):
        booking = self.bookings.get(booking_id)
        if not booking:
            print("Booking not found.")
            return

        new_check_in = check_in_date if check_in_date else booking.check_in_date
        new_check_out = check_out_date if check_out_date else booking.check_out_date

        for other_booking in self.bookings.values():
            if other_booking.booking_id == booking_id:
                continue
            if other_booking.room_number == booking.room_number:
                if not (new_check_out <= other_booking.check_in_date or new_check_in >= other_booking.check_out_date):
                    print(f"Error: Updated dates overlap with existing booking {other_booking.booking_id} in Room {booking.room_number}.")
                    return

        booking.check_in_date = new_check_in
        booking.check_out_date = new_check_out

        print(f"Booking {booking_id} updated successfully.")
        self.save_to_file()

    def update_booking_status(self, booking_id, new_status):
        booking = self.bookings.get(booking_id)
        if not booking:
            print("Booking not found.")
            return
        if new_status not in Booking.VALID_STATUSES:
            print(f"Invalid status. Valid statuses are: {', '.join(Booking.VALID_STATUSES)}")
            return
        if new_status == "checked-out" and not booking.is_paid:
            print("Cannot check-out: Booking not paid.")
            return
        booking.status = new_status
        print(f"Booking {booking_id} status updated to {new_status}.")
        self.save_to_file()

    def mark_booking_as_paid(self, booking_id):
        booking = self.bookings.get(booking_id)
        if booking:
            guest = self.guest_manager.get_guest(booking.guest_id)
            room = self.room_manager.get_room(booking.room_number)
            if guest and guest.guest_type == "member" and room:
                points_used = getattr(booking, 'points_used', 0)
                room_type = room.get_type().lower()
                cost_per_night = {
                    "single room": 10,
                    "double room": 15,
                    "deluxe room": 20,
                    "suite room": 25
                }.get(room_type, 0)

                nights = (booking.check_out_date - booking.check_in_date).days
                free_nights = points_used // cost_per_night if cost_per_night else 0
                paid_nights = nights - free_nights
                earned_points = paid_nights * 10

                guest.points += earned_points

            booking.is_paid = True
            print(f"Booking {booking_id} marked as paid.")
            self.save_to_file()
            self.guest_manager.save_guests()
        else:
            print("Booking not found.")

    def calculate_total_price(self, booking_id):
        booking = self.bookings.get(booking_id)
        if not booking:
            print("Booking not found.")
            return 0

        guest = self.guest_manager.get_guest(booking.guest_id)
        room = self.room_manager.get_room(booking.room_number)
        if not guest or not room:
            return 0

        nights = (booking.check_out_date - booking.check_in_date).days
        total_price = nights * room.price

        if guest.guest_type == "vip":
            total_price *= 0.8
        elif guest.guest_type == "member":
            # רק להחסיר את ההנחה שכבר שמרנו
            discount = getattr(booking, 'discount_from_points', 0)
            total_price -= discount
            guest.points += nights * 10

        return round(total_price, 2)

    def delete_booking(self, booking_id):
        booking = self.bookings.get(booking_id)
        if booking:
            guest = self.guest_manager.get_guest(booking.guest_id)
            if guest and guest.guest_type == "member":
                nights = (booking.check_out_date - booking.check_in_date).days
                guest.points = max(0, guest.points - nights * 10)

            room_number = booking.room_number
            del self.bookings[booking_id]
            print(f"Booking {booking_id} deleted successfully.")
            self.save_to_file()

            if self.waitlist_manager:
                next_guest = self.waitlist_manager.get_next_guest(room_number)
                if next_guest:
                    print(f"Guest {next_guest['guest_id']} is next in line for Room {room_number} and can be offered the room.")
        else:
            print("Booking not found.")

    def list_bookings(self):
        if not self.bookings:
            print("No bookings found.")
            return

        print("\n--- All Bookings ---")
        for idx, booking in enumerate(self.bookings.values()):
            guest = self.guest_manager.get_guest(booking.guest_id)
            if guest:
                print(f"Guest {guest.guest_id}: {guest.name}, Phone: {guest.phone}")

            nights = (booking.check_out_date - booking.check_in_date).days
            total_price = self.calculate_total_price(booking.booking_id)
            print(f"Booking {booking.booking_id}: Room {booking.room_number}, "
                  f"From {booking.check_in_date.strftime('%d-%m-%Y %H:%M')} to {booking.check_out_date.strftime('%d-%m-%Y %H:%M')}, "
                  f"({nights} night(s)), Status: {booking.status}, Paid: {'Yes' if booking.is_paid else 'No'}, Total: ${total_price}")
            if idx < len(self.bookings) - 1:
                print("-----------------------------------")

    def save_to_file(self):
        os.makedirs(os.path.dirname(self.filename), exist_ok=True)
        data = {
            booking_id: {
                "booking_id": booking.booking_id,
                "guest_id": booking.guest_id,
                "room_number": booking.room_number,
                "check_in_date": booking.check_in_date.strftime("%d-%m-%Y %H:%M"),
                "check_out_date": booking.check_out_date.strftime("%d-%m-%Y %H:%M"),
                "status": booking.status,
                "is_paid": booking.is_paid,
                "points_used": getattr(booking, 'points_used', 0),
                "discount_from_points": getattr(booking, 'discount_from_points', 0)
            } for booking_id, booking in self.bookings.items()
        }
        with open(self.filename, "w") as f:
            json.dump(data, f, indent=4)

    def load_from_file(self):
        if os.path.exists(self.filename):
            with open(self.filename, "r") as f:
                data = json.load(f)
                for booking_id, bdata in data.items():
                    check_in = datetime.strptime(bdata["check_in_date"], "%d-%m-%Y %H:%M")
                    check_out = datetime.strptime(bdata["check_out_date"], "%d-%m-%Y %H:%M")
                    booking = Booking(
                        bdata["booking_id"],
                        bdata["guest_id"],
                        bdata["room_number"],
                        check_in,
                        check_out,
                        bdata.get("status", "confirmed"),
                        bdata.get("is_paid", False)
                    )
                    booking.points_used = bdata.get("points_used", 0)
                    booking.discount_from_points = bdata.get("discount_from_points", 0)
                    self.bookings[booking_id] = booking

    def generate_invoice(self, booking_id):
        booking = self.bookings.get(booking_id)
        if not booking:
            print("Booking not found.")
            return

        guest = self.guest_manager.get_guest(booking.guest_id)
        room = self.room_manager.get_room(booking.room_number)
        if not guest or not room:
            return

        nights = (booking.check_out_date - booking.check_in_date).days
        original_total_price = nights * room.price
        payment_status = "Paid" if booking.is_paid else "Unpaid"

        # במקום לחשב מחדש — ניקח את מה שכבר שמור:
        points_used = getattr(booking, 'points_used', 0)
        discount = getattr(booking, 'discount_from_points', 0)

        # הוספת הנחה ל-VIP
        if guest.guest_type == "vip":
            discount = original_total_price * 0.2  # הנחה של 20%

        total_price = original_total_price - discount
        total_price = max(0, total_price)

        print("\n====== Invoice ======")
        print(f"Booking ID        : {booking.booking_id}")
        print(f"Guest Name        : {guest.name}")
        print(f"Phone Number      : {guest.phone}")
        print(f"Room Type         : {room.get_type()}")
        print(f"Room Number       : {room.room_number}")
        print(f"Check-in Date     : {booking.check_in_date.strftime('%d-%m-%Y %H:%M')}")
        print(f"Check-out Date    : {booking.check_out_date.strftime('%d-%m-%Y %H:%M')}")
        print(f"Nights            : {nights}")
        print(f"Price/Night       : ${room.price}")
        print(f"Total (Before Discount): ${original_total_price}")

        if guest.guest_type == "member":
            print(f"Points Balance    : {guest.points} points")
            print(f"Points Used       : {points_used} points")
            print(f"Discount from Points: ${discount}")
        elif guest.guest_type == "vip":
            print(f"VIP Discount      : ${discount}")

        print(f"Final Price       : ${total_price}")
        print(f"Payment Status    : {payment_status}")
        print("=====================")

        self.guest_manager.save_guests()