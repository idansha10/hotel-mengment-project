from collections import deque
import json
import os

class WaitlistManager:
    def __init__(self, filename="data/waitlist.json", load_from_file=True):
        self.waitlist = {}  # { room_number: deque of (guest_id, requested_check_in_date) }
        self.filename = filename
        self.load_from_file()

    def add_to_waitlist(self, room_number, guest_id, requested_date=None):
        if room_number not in self.waitlist:
            self.waitlist[room_number] = deque()

        self.waitlist[room_number].append({
            "guest_id": guest_id,
            "requested_date": requested_date.strftime("%d-%m-%Y %H:%M") if requested_date else None
        })
        print(f"Guest {guest_id} added to waitlist for room {room_number}.")
        self.save_to_file()

    def get_next_guest(self, room_number):
        if room_number in self.waitlist and self.waitlist[room_number]:
            return self.waitlist[room_number].popleft()  # FIFO
        return None

    def remove_guest(self, room_number, guest_id):
        if room_number in self.waitlist:
            updated_queue = deque(
                guest for guest in self.waitlist[room_number] if guest["guest_id"] != guest_id
            )
            self.waitlist[room_number] = updated_queue
            self.save_to_file()

    def save_to_file(self):
        # ממירים את הדק לכל ליסט
        serializable_waitlist = {room: list(guests) for room, guests in self.waitlist.items()}
        with open(self.filename, "w") as f:
            json.dump(serializable_waitlist, f, indent=4)

    def load_from_file(self):
        if os.path.exists(self.filename):
            with open(self.filename, "r") as f:
                raw_data = json.load(f)
                for room_number, guests in raw_data.items():
                    self.waitlist[room_number] = deque(guests)
