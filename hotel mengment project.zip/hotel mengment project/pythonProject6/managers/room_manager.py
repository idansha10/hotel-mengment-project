# managers/room_manager.py

import json
import os
from datetime import datetime
from models.room import Room
from models.room_factory import RoomFactory

class RoomManager:
    def __init__(self, filename="data/rooms.json"):
        self.rooms = {}
        self.filename = filename
        self.load_rooms()

    def load_rooms(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r") as f:
                    data = json.load(f)
                    for rn, rdata in data.items():
                        room_type = rdata["room_type"]
                        try:
                            room = RoomFactory.create_room(room_type, rdata["room_number"], rdata["price"])
                            room.is_available = rdata.get("is_available", True)
                        except ValueError:
                            room = Room(rdata["room_number"], rdata["price"], rdata.get("is_available", True))
                        self.rooms[rn] = room
            except Exception as e:
                print(f"[ERROR] Failed to load rooms: {e}")
        else:
            # אם לא קיים קובץ, ניצור קובץ ריק
            with open(self.filename, "w") as f:
                json.dump({}, f)

    def save_rooms(self):
        data = {
            rn: {
                "room_number": room.room_number,
                "room_type": room.get_type().lower().replace(" room", ""),
                "price": room.price,
                "is_available": room.is_available
            } for rn, room in self.rooms.items()
        }
        with open(self.filename, "w") as f:
            json.dump(data, f, indent=4)

    def create_room(self, room_number, room_type, price):
        if room_number in self.rooms:
            print("Room already exists.")
            return

        try:
            room = RoomFactory.create_room(room_type, room_number, price)
        except ValueError as e:
            print(e)
            return

        self.rooms[room_number] = room
        self.save_rooms()
        print(f"Room {room_number} added successfully.")

    def read_room(self, room_number):
        room = self.rooms.get(room_number)
        if room:
            print(room)
        else:
            print("Room not found.")

    def get_room(self, room_number):
        return self.rooms.get(room_number)

    def update_room(self, room_number, price=None):
        room = self.rooms.get(room_number)
        if room:
            if price is not None:
                room.price = price
            self.save_rooms()
            print("Room updated successfully.")
        else:
            print("Room not found.")

    def update_room_price(self, room_number, new_price):
        room = self.get_room(room_number)
        if not room:
            print("Room not found.")
            return

        min_prices = {
            "Single Room": 250,
            "Double Room": 400,
            "Suite Room": 700,
            "Deluxe Room": 1000
        }
        room_type = room.get_type()
        min_price = min_prices.get(room_type, 0)

        if new_price < min_price:
            print(f"Price too low. Minimum for {room_type} is {min_price}.")
            return

        room.price = new_price
        self.save_rooms()
        print("Room updated successfully.")

    def delete_room(self, room_number):
        if room_number in self.rooms:
            del self.rooms[room_number]
            self.save_rooms()
            print("Room deleted successfully.")
        else:
            print("Room not found.")

    def is_room_available(self, room_number, booking_manager):
        now = datetime.now()
        for booking in booking_manager.bookings.values():
            if booking.room_number == room_number and booking.check_out_date > now:
                return False
        return True

    def show_room_availability_report(self, booking_manager):
        print("\n--- Room Availability Report ---")
        if not self.rooms:
            print("No rooms found.")
            return
        for room in self.rooms.values():
            status = "Available" if self.is_room_available(room.room_number, booking_manager) else "Occupied"
            print(f"Room {room.room_number} ({room.get_type()}) → {status}")

    def show_all_rooms_with_status(self, booking_manager):
        print("\n--- All Rooms ---")
        if not self.rooms:
            print("No rooms found.")
            return
        for room in self.rooms.values():
            status = "Available" if self.is_room_available(room.room_number, booking_manager) else "Occupied"
            print(f"Room {room.room_number}: {room.get_type()}, ${room.price}, Status: {status}")