import json
import os
from models.guest import Guest

class GuestManager:
    def __init__(self, filename="data/guests.json"):
        self.guests = {}  # Dictionary of all guests
        self.filename = filename
        self.load_guests()

    def load_guests(self):
        if os.path.exists(self.filename):
            try:
                with open(self.filename, "r") as f:
                    data = json.load(f)
                    for gid, gdata in data.items():
                        self.guests[gid] = Guest(**gdata)
            except Exception as e:
                print(f"[ERROR] Failed to load guests: {e}")
        else:
            os.makedirs(os.path.dirname(self.filename), exist_ok=True)
            with open(self.filename, "w") as f:
                json.dump({}, f)

    def save_guests(self):
        try:
            data = {gid: guest.to_dict() for gid, guest in self.guests.items()}
            with open(self.filename, "w") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            print(f"[ERROR] Failed to save guests: {e}")

    def validate_guest_id(self, guest_id):
        """Validate guest ID: exactly 9 digits."""
        return guest_id.isdigit() and len(guest_id) == 9

    def validate_phone(self, phone):
        """Validate phone number: exactly 10 digits."""
        return phone.isdigit() and len(phone) == 10

    def add_guest(self, guest):
        """Add a new guest after validation."""
        if not self.validate_guest_id(guest.guest_id):
            print("Invalid Guest ID. Must be exactly 9 digits.")
            return
        if not self.validate_phone(guest.phone):
            print("Invalid Phone Number. Must be exactly 10 digits.")
            return
        if guest.guest_id in self.guests:
            print("Guest already exists.")
            return
        self.guests[guest.guest_id] = guest
        self.save_guests()
        print("Guest registered successfully.")

    def register_guest(self, guest_id, name, phone, guest_type="regular", is_paid=False):
        """Register a new guest using details."""
        if not self.validate_guest_id(guest_id):
            print("Invalid Guest ID. Must be exactly 9 digits.")
            return
        if not self.validate_phone(phone):
            print("Invalid Phone Number. Must be exactly 10 digits.")
            return
        if guest_id in self.guests:
            print("Guest already exists.")
            return
        guest = Guest(guest_id, name, phone, guest_type, 0, is_paid)
        self.guests[guest_id] = guest
        self.save_guests()
        print("Guest registered successfully.")
    def update_guest(self, guest_id, name=None, phone=None, guest_type=None, is_paid=None):
        """Update guest details."""
        guest = self.guests.get(guest_id)
        if not guest:
            print("Guest not found.")
            return

        if guest_type:
            if guest.guest_type == "member" and guest_type == "vip":
                guest.points = 0  # Reset points on upgrade to VIP
            guest.guest_type = guest_type

        if name:
            guest.name = name
        if phone:
            if not self.validate_phone(phone):
                print("Invalid Phone Number. Must be exactly 10 digits.")
                return
            guest.phone = phone
        if is_paid is not None:
            guest.is_paid = is_paid

        self.save_guests()
        print("Guest updated successfully.")

    def list_all_guests(self):
        """Display all guests."""
        if not self.guests:
            print("No guests found.")
            return

        print("\n--- All Guests ---")
        for guest in self.guests.values():
            print(f"ID      : {guest.guest_id}")
            print(f"Name    : {guest.name}")
            print(f"Phone   : {guest.phone}")
            print(f"Type    : {guest.guest_type}")
            if guest.guest_type == "member":
                print(f"Points  : {guest.points}")
            print(f"Is Paid : {'Yes' if guest.is_paid else 'No'}")
            print("-" * 30)

    def get_guest(self, guest_id):
        """Retrieve a guest by ID."""
        return self.guests.get(guest_id)

    def delete_guest(self, guest_id):
        """Delete a guest from the dictionary."""
        if guest_id in self.guests:
            del self.guests[guest_id]
            self.save_guests()
            print("Guest deleted successfully.")
        else:
            print("Guest not found.")
